Para acceder al crud deberá acceder desde aquí:
http://mladaria.ifc33b.cifpfbmoll.eu/dwes_2021-MLS535/mladariaBD_agenda/